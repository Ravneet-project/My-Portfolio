import React from 'react';
import DeskHome from './components/DeskHome';

export default function App(){
  return <DeskHome />;
}
