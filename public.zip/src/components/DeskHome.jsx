import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import AboutPopup from './AboutPopup';
import ProjectsPopup from './ProjectsPopup';
import ContactPopup from './ContactPopup';
import deskDay from '../assets/desk-day.svg';
import deskNight from '../assets/desk-night.svg';

export default function DeskHome(){
  const [theme, setTheme] = useState('day');
  const [showAbout, setShowAbout] = useState(false);
  const [showProjects, setShowProjects] = useState(false);
  const [showContact, setShowContact] = useState(false);

  useEffect(()=>{
    const hour = new Date().getHours();
    if(hour>=6 && hour<18) setTheme('day');
    else setTheme('night');
  },[]);

  return (
    <motion.div
      className={`desk-container ${theme}`}
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 1.1 }}
    >
      <img src={theme==='day'?deskDay:deskNight} alt="desk" className="desk-bg" />

      <motion.div className="clickable laptop" onClick={()=>setShowProjects(true)} whileHover={{ scale: 1.05 }}>
        💻
      </motion.div>

      <motion.div className="clickable mug" onClick={()=>setShowAbout(true)} whileHover={{ rotate: 8 }}>
        ☕
      </motion.div>

      <motion.div className="clickable notebook" onClick={()=>window.open('/resume.pdf','_blank')} whileHover={{ y: -6 }}>
        📒
      </motion.div>

      <motion.div className="clickable phone" onClick={()=>setShowContact(true)} whileHover={{ scale: 1.05 }}>
        📱
      </motion.div>

      <div className="theme-label">{theme==='day'?'☀️ Good Morning!':'🌙 Good Evening!'}</div>

      {showAbout && <AboutPopup onClose={()=>setShowAbout(false)} />}
      {showProjects && <ProjectsPopup onClose={()=>setShowProjects(false)} />}
      {showContact && <ContactPopup onClose={()=>setShowContact(false)} />}
    </motion.div>
  );
}
