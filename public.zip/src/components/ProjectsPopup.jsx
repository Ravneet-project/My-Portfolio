import React from 'react';
import { motion } from 'framer-motion';

export default function ProjectsPopup({ onClose }){
  return (
    <motion.div className="popup" initial={{ y:-50, opacity:0 }} animate={{ y:0, opacity:1 }}>
      <h2>My Projects 💻</h2>
      <ul>
        <li>Helping Hands (Donation Portal)</li>
        <li>Feedback Management System</li>
        <li>Habit Tracker App</li>
      </ul>
      <button onClick={onClose}>Close</button>
    </motion.div>
  );
}
