import React from 'react';
import { motion } from 'framer-motion';

export default function AboutPopup({ onClose }){
  return (
    <motion.div className="popup" initial={{ scale:0.8, opacity:0 }} animate={{ scale:1, opacity:1 }}>
      <h2>About Me ☕</h2>
      <p>Hi, I'm Ravneet — a passionate web developer.</p>
      <button onClick={onClose}>Close</button>
    </motion.div>
  );
}
