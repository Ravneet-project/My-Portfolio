import React from 'react';
import { motion } from 'framer-motion';

export default function ContactPopup({ onClose }){
  return (
    <motion.div className="popup" initial={{ scale:0.9, opacity:0 }} animate={{ scale:1, opacity:1 }}>
      <h2>Contact Me 📱</h2>
      <p>Email: ravneet@example.com</p>
      <p>LinkedIn: linkedin.com/in/ravneetsawhney</p>
      <button onClick={onClose}>Close</button>
    </motion.div>
  );
}
